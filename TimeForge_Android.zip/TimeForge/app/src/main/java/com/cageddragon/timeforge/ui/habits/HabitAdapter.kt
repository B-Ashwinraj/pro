package com.cageddragon.timeforge.ui.habits

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cageddragon.timeforge.data.Habit
import com.cageddragon.timeforge.databinding.ItemHabitBinding

class HabitAdapter(
    private val vm: HabitsViewModel,
    private val onToggle: (Habit) -> Unit,
    private val onDelete: (Habit) -> Unit
) : ListAdapter<Habit, HabitAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemHabitBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemHabitBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val habit = getItem(position)
        val b = holder.binding
        b.tvHabitIcon.text = habit.icon
        b.tvHabitName.text = habit.name
        val streakIcon = when {
            habit.streak >= 7 -> "🔥"
            habit.streak >= 3 -> "⚡"
            else -> "✦"
        }
        b.tvHabitStreak.text = "$streakIcon ${habit.streak} day streak"
        b.tvHabitBest.text = "Best: ${habit.best}"
        val today = vm.todayKey()
        val log = vm.parseLog(habit.logJson)
        b.cbHabitToday.setOnCheckedChangeListener(null)
        b.cbHabitToday.isChecked = log[today] == true
        b.cbHabitToday.setOnCheckedChangeListener { _, _ -> onToggle(habit) }
        b.btnDeleteHabit.setOnClickListener { onDelete(habit) }
        buildHeatmap(b.llHeatmap, habit, log)
    }

    private fun buildHeatmap(container: LinearLayout, habit: Habit, log: Map<String, Boolean>) {
        container.removeAllViews()
        val keys = vm.last14Keys()
        val dp = container.context.resources.displayMetrics.density
        val dotSize = (18 * dp).toInt()
        val dotMargin = (3 * dp).toInt()
        val habitColor = try { Color.parseColor(habit.color) } catch (e: Exception) { Color.parseColor("#C9A84C") }
        keys.forEach { key ->
            val dot = TextView(container.context)
            val lp = LinearLayout.LayoutParams(dotSize, dotSize)
            lp.setMargins(dotMargin, 0, dotMargin, 0)
            dot.layoutParams = lp
            dot.text = ""
            dot.setBackgroundColor(if (log[key] == true) habitColor else Color.parseColor("#1AC9A84C"))
            container.addView(dot)
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Habit>() {
            override fun areItemsTheSame(a: Habit, b: Habit) = a.id == b.id
            override fun areContentsTheSame(a: Habit, b: Habit) = a == b
        }
    }
}
