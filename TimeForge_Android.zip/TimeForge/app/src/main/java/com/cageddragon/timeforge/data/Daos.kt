package com.cageddragon.timeforge.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY done ASC, CASE importance WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END ASC")
    fun getAll(): LiveData<List<Task>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: Task)
    @Update
    suspend fun update(task: Task)
    @Delete
    suspend fun delete(task: Task)
    @Query("DELETE FROM tasks")
    suspend fun deleteAll()
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals ORDER BY CASE importance WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END ASC")
    fun getAll(): LiveData<List<Goal>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(goal: Goal)
    @Update
    suspend fun update(goal: Goal)
    @Delete
    suspend fun delete(goal: Goal)
}

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits")
    fun getAll(): LiveData<List<Habit>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(habit: Habit)
    @Update
    suspend fun update(habit: Habit)
    @Delete
    suspend fun delete(habit: Habit)
}

@Dao
interface TimetableDao {
    @Query("SELECT * FROM timetable_blocks ORDER BY day ASC, startTime ASC")
    fun getAll(): LiveData<List<TimetableBlock>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(block: TimetableBlock)
    @Delete
    suspend fun delete(block: TimetableBlock)
}

@Dao
interface ReviewDao {
    @Query("SELECT * FROM reviews ORDER BY dateKey DESC")
    fun getAll(): LiveData<List<Review>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(review: Review)
    @Query("SELECT * FROM reviews WHERE dateKey = :key LIMIT 1")
    suspend fun getByDate(key: String): Review?
}

@Dao
interface FocusSessionDao {
    @Query("SELECT * FROM focus_sessions ORDER BY id DESC")
    fun getAll(): LiveData<List<FocusSession>>
    @Insert
    suspend fun insert(session: FocusSession)
    @Query("SELECT * FROM focus_sessions WHERE date = :date")
    suspend fun getByDate(date: String): List<FocusSession>
}
