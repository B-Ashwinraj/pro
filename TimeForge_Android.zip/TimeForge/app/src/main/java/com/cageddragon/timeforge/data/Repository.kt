package com.cageddragon.timeforge.data

import android.content.Context
import androidx.lifecycle.LiveData

class Repository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val taskDao = db.taskDao()
    private val goalDao = db.goalDao()
    private val habitDao = db.habitDao()
    private val timetableDao = db.timetableDao()
    private val reviewDao = db.reviewDao()
    private val sessionDao = db.focusSessionDao()

    val tasks: LiveData<List<Task>> = taskDao.getAll()
    val goals: LiveData<List<Goal>> = goalDao.getAll()
    val habits: LiveData<List<Habit>> = habitDao.getAll()
    val timetableBlocks: LiveData<List<TimetableBlock>> = timetableDao.getAll()
    val reviews: LiveData<List<Review>> = reviewDao.getAll()
    val sessions: LiveData<List<FocusSession>> = sessionDao.getAll()

    suspend fun insertTask(task: Task) = taskDao.insert(task)
    suspend fun updateTask(task: Task) = taskDao.update(task)
    suspend fun deleteTask(task: Task) = taskDao.delete(task)
    suspend fun insertGoal(goal: Goal) = goalDao.insert(goal)
    suspend fun updateGoal(goal: Goal) = goalDao.update(goal)
    suspend fun deleteGoal(goal: Goal) = goalDao.delete(goal)
    suspend fun insertHabit(habit: Habit) = habitDao.insert(habit)
    suspend fun updateHabit(habit: Habit) = habitDao.update(habit)
    suspend fun deleteHabit(habit: Habit) = habitDao.delete(habit)
    suspend fun insertBlock(block: TimetableBlock) = timetableDao.insert(block)
    suspend fun deleteBlock(block: TimetableBlock) = timetableDao.delete(block)
    suspend fun insertReview(review: Review) = reviewDao.insert(review)
    suspend fun getReviewByDate(key: String) = reviewDao.getByDate(key)
    suspend fun insertSession(session: FocusSession) = sessionDao.insert(session)
    suspend fun getSessionsByDate(date: String) = sessionDao.getByDate(date)
}
