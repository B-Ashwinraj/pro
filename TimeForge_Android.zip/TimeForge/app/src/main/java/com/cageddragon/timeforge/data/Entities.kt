package com.cageddragon.timeforge.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val importance: String = "medium",
    val startTime: String = "",
    val duration: Int = 30,
    val deadline: String = "",
    val done: Boolean = false,
    val category: String = "",
    val notes: String = "",
    val completedAt: String = ""
)

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String = "",
    val horizon: String = "1 month",
    val progress: Int = 0,
    val importance: String = "medium"
)

@Entity(tableName = "habits")
data class Habit(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val nameTa: String = "",
    val icon: String = "⚡",
    val color: String = "#C9A84C",
    val streak: Int = 0,
    val best: Int = 0,
    val logJson: String = "{}"
)

@Entity(tableName = "timetable_blocks")
data class TimetableBlock(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val day: Int = 0,
    val startTime: String,
    val endTime: String,
    val subject: String,
    val colorHex: String = "#C9A84C"
)

@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey val dateKey: String,
    val mood: String = "",
    val wins: String = "",
    val learnings: String = "",
    val top3: String = "",
    val improve: String = ""
)

@Entity(tableName = "focus_sessions")
data class FocusSession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val duration: Int,
    val mode: String = "focus",
    val completed: Boolean = false,
    val taskId: Int = 0
)
