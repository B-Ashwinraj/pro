package com.cageddragon.timeforge.ui.today

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cageddragon.timeforge.data.Repository
import com.cageddragon.timeforge.data.Task
import kotlinx.coroutines.launch
import java.time.LocalDateTime

class TodayViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)
    val tasks = repo.tasks

    fun addTask(task: Task) = viewModelScope.launch { repo.insertTask(task) }
    fun updateTask(task: Task) = viewModelScope.launch { repo.updateTask(task) }
    fun deleteTask(task: Task) = viewModelScope.launch { repo.deleteTask(task) }
    fun toggleDone(task: Task) {
        val now = if (!task.done) LocalDateTime.now().toString() else ""
        viewModelScope.launch { repo.updateTask(task.copy(done = !task.done, completedAt = now)) }
    }
}
