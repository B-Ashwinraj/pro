package com.cageddragon.timeforge.ui.goals

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.cageddragon.timeforge.data.Goal
import com.cageddragon.timeforge.databinding.DialogAddGoalBinding
import com.cageddragon.timeforge.databinding.FragmentGoalsBinding

class GoalsFragment : Fragment() {
    private var _binding: FragmentGoalsBinding? = null
    private val binding get() = _binding!!
    private val vm: GoalsViewModel by viewModels()
    private lateinit var adapter: GoalAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentGoalsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = GoalAdapter(onNudge = { goal, delta -> vm.nudgeProgress(goal, delta) }, onDelete = { vm.deleteGoal(it) })
        binding.rvGoals.layoutManager = LinearLayoutManager(requireContext())
        binding.rvGoals.adapter = adapter
        vm.goals.observe(viewLifecycleOwner) { goals ->
            adapter.submitList(goals)
            if (goals.isEmpty()) {
                binding.rvGoals.visibility = View.GONE
                binding.tvEmptyGoals.visibility = View.VISIBLE
            } else {
                binding.rvGoals.visibility = View.VISIBLE
                binding.tvEmptyGoals.visibility = View.GONE
            }
        }
        binding.btnAddGoal.setOnClickListener { showAddGoalDialog() }
    }

    private fun showAddGoalDialog() {
        val dBinding = DialogAddGoalBinding.inflate(layoutInflater)
        val horizons = arrayOf("1 month","2 months","3 months","6 months","1 year","2 years","5 years")
        val importances = arrayOf("Critical","High","Medium","Low")
        dBinding.spHorizon.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, horizons).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        dBinding.spGoalImportance.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, importances).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        dBinding.spGoalImportance.setSelection(2)
        val dialog = AlertDialog.Builder(requireContext()).setView(dBinding.root).create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dBinding.btnCancelGoal.setOnClickListener { dialog.dismiss() }
        dBinding.btnSaveGoal.setOnClickListener {
            val name = dBinding.etGoalName.text.toString().trim()
            if (name.isEmpty()) { dBinding.etGoalName.error = "Required"; return@setOnClickListener }
            vm.addGoal(Goal(
                name = name,
                description = dBinding.etGoalDesc.text.toString().trim(),
                horizon = horizons[dBinding.spHorizon.selectedItemPosition],
                importance = importances[dBinding.spGoalImportance.selectedItemPosition].lowercase(),
                progress = 0
            ))
            dialog.dismiss()
        }
        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
