package com.cageddragon.timeforge.ui.timetable
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.cageddragon.timeforge.R
import com.cageddragon.timeforge.data.TimetableBlock
import com.cageddragon.timeforge.databinding.DialogAddBlockBinding
import com.cageddragon.timeforge.databinding.FragmentTimetableBinding
class TimetableFragment : Fragment() {
private var _binding: FragmentTimetableBinding? = null
private val binding get() = _binding!!
private val vm: TimetableViewModel by viewModels()
private val days = listOf("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")
private var selectedDay = 0
override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
_binding = FragmentTimetableBinding.inflate(inflater, container, false)
return binding.root
}
override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
buildDayTabs()
vm.blocks.observe(viewLifecycleOwner) { renderSlots(it) }
binding.btnAddBlock.setOnClickListener { showAddBlockDialog() }
}
private fun buildDayTabs() {
val ctx = requireContext()
val dp = ctx.resources.displayMetrics.density
days.forEachIndexed { i, day ->
val btn = Button(ctx)
btn.text = day.take(3)
btn.textSize = 12f
val lp = LinearLayout.LayoutParams((60 * dp).toInt(), (36 * dp).toInt())
lp.marginEnd = (6 * dp).toInt()
btn.layoutParams = lp
btn.setOnClickListener { selectedDay = i; updateDayTabColors(); renderSlots(vm.blocks.value ?: emptyList()) }
binding.llDayTabs.addView(btn)
}
updateDayTabColors()
}
private fun updateDayTabColors() {
val gold = requireContext().getColor(R.color.gold)
val navy = requireContext().getColor(R.color.navy)
val surface = requireContext().getColor(R.color.surface)
val textMuted = requireContext().getColor(R.color.text_muted)
for (i in 0 until binding.llDayTabs.childCount) {
val btn = binding.llDayTabs.getChildAt(i) as Button
if (i == selectedDay) {
btn.backgroundTintList = android.content.res.ColorStateList.valueOf(gold)
btn.setTextColor(navy)
} else {
btn.backgroundTintList = android.content.res.ColorStateList.valueOf(surface)
btn.setTextColor(textMuted)
}
}
}
private fun renderSlots(blocks: List<TimetableBlock>) {
val ctx = requireContext()
val dp = ctx.resources.displayMetrics.density
val container = binding.llTimetableSlots
container.removeAllViews()
val hours = listOf("06:00","07:00","08:00","09:00","10:00","11:00","12:00",
"13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00")
val dayBlocks = blocks.filter { it.day == selectedDay }
hours.forEach { hour ->
val row = LinearLayout(ctx)
row.orientation = LinearLayout.HORIZONTAL
row.gravity = Gravity.CENTER_VERTICAL
val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (52 * dp).toInt())
lp.bottomMargin = (4 * dp).toInt()
row.layoutParams = lp
val timeLbl = TextView(ctx)
timeLbl.text = hour
timeLbl.textSize = 11f
timeLbl.setTextColor(ctx.getColor(R.color.text_muted))
timeLbl.layoutParams = LinearLayout.LayoutParams((52 * dp).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT)
row.addView(timeLbl)
val block = dayBlocks.firstOrNull { it.startTime == hour }
if (block != null) {
val blockView = TextView(ctx)
blockView.text = "${block.subject}\n${block.startTime}–${block.endTime}"
blockView.textSize = 12f
blockView.setTextColor(Color.WHITE)
blockView.setPadding((10 * dp).toInt(), (6 * dp).toInt(), (10 * dp).toInt(), (6 * dp).toInt())
val blockLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
blockView.layoutParams = blockLp
try {
val c = Color.parseColor(block.colorHex)
blockView.setBackgroundColor(Color.argb(200, Color.red(c), Color.green(c), Color.blue(c)))
} catch (e: Exception) {
blockView.setBackgroundColor(ctx.getColor(R.color.surface))
}
blockView.setOnLongClickListener {
AlertDialog.Builder(ctx)
.setTitle("Delete block?")
.setMessage(block.subject)
.setPositiveButton("Delete") { _, _ -> vm.deleteBlock(block) }
.setNegativeButton("Cancel", null)
.show()
true
}
row.addView(blockView)
} else {
val emptyView = View(ctx)
emptyView.layoutParams = LinearLayout.LayoutParams(0, (1 * dp).toInt(), 1f)
emptyView.setBackgroundColor(ctx.getColor(R.color.border))
row.addView(emptyView)
}
container.addView(row)
}
}
private fun showAddBlockDialog() {
val dBinding = DialogAddBlockBinding.inflate(layoutInflater)
val dayAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, days)
dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
dBinding.spBlockDay.adapter = dayAdapter
dBinding.spBlockDay.setSelection(selectedDay)
val dialog = AlertDialog.Builder(requireContext())
.setView(dBinding.root)
.create()
dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
dBinding.btnCancelBlock.setOnClickListener { dialog.dismiss() }
dBinding.btnSaveBlock.setOnClickListener {
val subject = dBinding.etBlockSubject.text.toString().trim()
if (subject.isEmpty()) { dBinding.etBlockSubject.error = "Required"; return@setOnClickListener }
val start = dBinding.etBlockStart.text.toString().trim().ifEmpty { "09:00" }
val end = dBinding.etBlockEnd.text.toString().trim().ifEmpty { "10:00" }
val color = dBinding.etBlockColor.text.toString().trim().ifEmpty { "#C9A84C" }
val day = dBinding.spBlockDay.selectedItemPosition
vm.addBlock(TimetableBlock(day = day, startTime = start, endTime = end, subject = subject, colorHex = color))
dialog.dismiss()
}
dialog.show()
}
override fun onDestroyView() {
super.onDestroyView()
_binding = null
}
}