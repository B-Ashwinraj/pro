package com.cageddragon.timeforge.ui.goals

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cageddragon.timeforge.data.Goal
import com.cageddragon.timeforge.data.Repository
import kotlinx.coroutines.launch

class GoalsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)
    val goals = repo.goals

    fun addGoal(goal: Goal) = viewModelScope.launch { repo.insertGoal(goal) }
    fun updateGoal(goal: Goal) = viewModelScope.launch { repo.updateGoal(goal) }
    fun deleteGoal(goal: Goal) = viewModelScope.launch { repo.deleteGoal(goal) }
    fun nudgeProgress(goal: Goal, delta: Int) {
        val clamped = (goal.progress + delta).coerceIn(0, 100)
        viewModelScope.launch { repo.updateGoal(goal.copy(progress = clamped)) }
    }
}
