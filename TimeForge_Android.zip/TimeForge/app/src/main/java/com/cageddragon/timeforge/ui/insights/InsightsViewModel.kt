package com.cageddragon.timeforge.ui.insights

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.cageddragon.timeforge.data.Repository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class InsightStats(
    val tasksToday: Int = 0,
    val tasksDoneToday: Int = 0,
    val tasksTotal: Int = 0,
    val focusMinutesToday: Int = 0,
    val focusSessionsToday: Int = 0,
    val topHabitStreak: Int = 0,
    val activeHabits: Int = 0,
    val habitsCompletedToday: Int = 0,
    val goalsInProgress: Int = 0,
    val goalsCompleted: Int = 0,
    val avgGoalProgress: Int = 0,
    val recommendation: String = ""
)

class InsightsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)
    val tasks = repo.tasks
    val goals = repo.goals
    val habits = repo.habits
    val sessions = repo.sessions

    private val _stats = MutableLiveData<InsightStats>()
    val stats: LiveData<InsightStats> = _stats

    fun compute(
        taskList: List<com.cageddragon.timeforge.data.Task>,
        goalList: List<com.cageddragon.timeforge.data.Goal>,
        habitList: List<com.cageddragon.timeforge.data.Habit>,
        sessionList: List<com.cageddragon.timeforge.data.FocusSession>
    ) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        val tasksToday = taskList.size
        val tasksDoneToday = taskList.count { it.done }
        val tasksTotal = taskList.size

        val todaySessions = sessionList.filter { it.date == today }
        val focusMins = todaySessions.sumOf { it.duration } / 60

        val topStreak = habitList.maxOfOrNull { it.streak } ?: 0
        val habitsToday = habitList.count { habit ->
            try {
                val type = object : com.google.gson.reflect.TypeToken<Map<String, Boolean>>() {}.type
                val log: Map<String, Boolean> = com.google.gson.Gson().fromJson(habit.logJson, type) ?: emptyMap()
                log[today] == true
            } catch (e: Exception) { false }
        }

        val goalsInProgress = goalList.count { it.progress in 1..99 }
        val goalsCompleted = goalList.count { it.progress >= 100 }
        val avgProgress = if (goalList.isNotEmpty()) goalList.sumOf { it.progress } / goalList.size else 0

        val rec = buildRecommendation(tasksDoneToday, tasksToday, focusMins, topStreak, avgProgress)

        _stats.postValue(
            InsightStats(
                tasksToday = tasksToday,
                tasksDoneToday = tasksDoneToday,
                tasksTotal = tasksTotal,
                focusMinutesToday = focusMins,
                focusSessionsToday = todaySessions.size,
                topHabitStreak = topStreak,
                activeHabits = habitList.size,
                habitsCompletedToday = habitsToday,
                goalsInProgress = goalsInProgress,
                goalsCompleted = goalsCompleted,
                avgGoalProgress = avgProgress,
                recommendation = rec
            )
        )
    }

    private fun buildRecommendation(
        done: Int, total: Int, focusMins: Int, streak: Int, avgGoal: Int
    ): String {
        return when {
            total == 0 -> "Start your day — add tasks to your forge."
            done == 0 -> "You have $total tasks waiting. Pick the hardest one first."
            focusMins == 0 -> "No focus sessions yet today. Start a 25-min sprint!"
            streak == 0 -> "Begin a habit today — even one day builds momentum."
            done < total / 2 -> "Halfway there! ${total - done} tasks remaining."
            avgGoal < 20 -> "Update your goal progress — small nudges add up."
            else -> "Excellent forge work! Keep the momentum going. 🔥"
        }
    }
}
