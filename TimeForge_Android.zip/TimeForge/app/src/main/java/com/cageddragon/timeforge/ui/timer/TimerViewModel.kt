package com.cageddragon.timeforge.ui.timer

import android.app.Application
import android.os.CountDownTimer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.cageddragon.timeforge.data.FocusSession
import com.cageddragon.timeforge.data.Repository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TimerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)

    enum class Mode(val seconds: Long, val label: String) {
        FOCUS(25 * 60L, "Focus"),
        SHORT(5 * 60L, "Short Break"),
        LONG(15 * 60L, "Long Break")
    }

    private var timer: CountDownTimer? = null
    private val _timeLeft = MutableLiveData(25 * 60L)
    val timeLeft: LiveData<Long> = _timeLeft
    private val _running = MutableLiveData(false)
    val running: LiveData<Boolean> = _running
    private val _mode = MutableLiveData(Mode.FOCUS)
    val mode: LiveData<Mode> = _mode
    private val _sessionsDone = MutableLiveData(0)
    val sessionsDone: LiveData<Int> = _sessionsDone
    private val _focusMinutes = MutableLiveData(0)
    val focusMinutes: LiveData<Int> = _focusMinutes
    private var sessionStart = 0L

    fun setMode(m: Mode) {
        if (_running.value == true) return
        timer?.cancel()
        _mode.value = m
        _timeLeft.value = m.seconds
        _running.value = false
    }

    fun startStop() {
        if (_running.value == true) {
            timer?.cancel()
            _running.value = false
            return
        }
        sessionStart = System.currentTimeMillis()
        _running.value = true
        timer = object : CountDownTimer((_timeLeft.value ?: _mode.value!!.seconds) * 1000L, 1000L) {
            override fun onTick(ms: Long) { _timeLeft.value = ms / 1000 }
            override fun onFinish() {
                _running.value = false
                _timeLeft.value = 0
                val dur = (System.currentTimeMillis() - sessionStart).toInt() / 1000
                saveSession(dur)
                _sessionsDone.value = (_sessionsDone.value ?: 0) + 1
                _focusMinutes.value = (_focusMinutes.value ?: 0) + dur / 60
                _timeLeft.value = _mode.value?.seconds ?: (25 * 60L)
            }
        }.start()
    }

    private fun saveSession(dur: Int) {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        viewModelScope.launch {
            repo.insertSession(FocusSession(date = date, duration = dur, mode = _mode.value?.name?.lowercase() ?: "focus", completed = true))
        }
    }

    override fun onCleared() {
        super.onCleared()
        timer?.cancel()
    }
}
