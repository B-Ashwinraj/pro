package com.cageddragon.timeforge.ui.timer

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.cageddragon.timeforge.R
import com.cageddragon.timeforge.databinding.FragmentTimerBinding

class TimerFragment : Fragment() {
    private var _binding: FragmentTimerBinding? = null
    private val binding get() = _binding!!
    private val vm: TimerViewModel by viewModels()

    private val tips = listOf(
        "Tackle your most feared task within the first 90 minutes. Willpower peaks at dawn.",
        "Your brain cycles in 90-min focus windows. A 20-min break prevents cognitive fatigue.",
        "Implementation intention: say 'When I sit down, I will begin [task].' Boosts follow-through by 91%.",
        "Flow emerges when challenge is 4% above current skill. Find the edge.",
        "If a task takes under 2 minutes, do it now. Scheduling overhead costs more mental energy."
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTimerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.tvTipBody.text = tips[(System.currentTimeMillis() % tips.size).toInt()]

        vm.timeLeft.observe(viewLifecycleOwner) { secs ->
            val m = secs / 60; val s = secs % 60
            binding.tvTimerDisplay.text = "%02d:%02d".format(m, s)
        }
        vm.running.observe(viewLifecycleOwner) { running ->
            binding.btnStart.text = if (running) "Pause" else "Start"
        }
        vm.mode.observe(viewLifecycleOwner) { mode ->
            binding.tvTimerModeLabel.text = mode.label
            updateModeButtons(mode)
        }
        vm.sessionsDone.observe(viewLifecycleOwner) { count ->
            if (count > 0) playChime()
            binding.tvSessionCount.text = if (count == 0) "No sessions yet" else "$count session${if (count > 1) "s" else ""} completed today"
        }
        vm.focusMinutes.observe(viewLifecycleOwner) { mins ->
            if (mins > 0) binding.tvFocusMinutes.text = "$mins focus minutes today"
        }
        binding.btnStart.setOnClickListener { vm.startStop() }
        binding.btnStop.setOnClickListener { vm.setMode(vm.mode.value ?: TimerViewModel.Mode.FOCUS) }
        binding.btnModeFocus.setOnClickListener { vm.setMode(TimerViewModel.Mode.FOCUS) }
        binding.btnModeShort.setOnClickListener { vm.setMode(TimerViewModel.Mode.SHORT) }
        binding.btnModeLong.setOnClickListener { vm.setMode(TimerViewModel.Mode.LONG) }
    }

    private fun updateModeButtons(mode: TimerViewModel.Mode) {
        val ctx = requireContext()
        val gold = ctx.getColor(R.color.gold)
        val navy = ctx.getColor(R.color.navy)
        val surface = ctx.getColor(R.color.surface)
        val textMuted = ctx.getColor(R.color.text_muted)
        listOf(
            binding.btnModeFocus to TimerViewModel.Mode.FOCUS,
            binding.btnModeShort to TimerViewModel.Mode.SHORT,
            binding.btnModeLong to TimerViewModel.Mode.LONG
        ).forEach { (btn, m) ->
            if (m == mode) {
                btn.backgroundTintList = android.content.res.ColorStateList.valueOf(gold)
                btn.setTextColor(navy)
            } else {
                btn.backgroundTintList = android.content.res.ColorStateList.valueOf(surface)
                btn.setTextColor(textMuted)
            }
        }
    }

    private fun playChime() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 400)
        } catch (e: Exception) { }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
