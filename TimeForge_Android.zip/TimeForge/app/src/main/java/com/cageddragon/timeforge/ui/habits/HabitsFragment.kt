package com.cageddragon.timeforge.ui.habits

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.cageddragon.timeforge.data.Habit
import com.cageddragon.timeforge.databinding.DialogAddHabitBinding
import com.cageddragon.timeforge.databinding.FragmentHabitsBinding

class HabitsFragment : Fragment() {
    private var _binding: FragmentHabitsBinding? = null
    private val binding get() = _binding!!
    private val vm: HabitsViewModel by viewModels()
    private lateinit var adapter: HabitAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHabitsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = HabitAdapter(vm = vm, onToggle = { vm.toggleToday(it) }, onDelete = { vm.deleteHabit(it) })
        binding.rvHabits.layoutManager = LinearLayoutManager(requireContext())
        binding.rvHabits.adapter = adapter
        vm.habits.observe(viewLifecycleOwner) { habits ->
            adapter.submitList(habits)
            val today = vm.todayKey()
            val doneToday = habits.count { vm.parseLog(it.logJson)[today] == true }
            val bestStreak = habits.maxOfOrNull { it.best } ?: 0
            val sevenPlus = habits.count { it.streak >= 7 }
            binding.tvHabitsToday.text = doneToday.toString()
            binding.tvBestStreak.text = bestStreak.toString()
            binding.tvStreaks7.text = sevenPlus.toString()
            if (habits.isEmpty()) {
                binding.rvHabits.visibility = View.GONE
                binding.tvEmptyHabits.visibility = View.VISIBLE
            } else {
                binding.rvHabits.visibility = View.VISIBLE
                binding.tvEmptyHabits.visibility = View.GONE
            }
        }
        binding.btnAddHabit.setOnClickListener { showAddHabitDialog() }
    }

    private fun showAddHabitDialog() {
        val dBinding = DialogAddHabitBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(requireContext()).setView(dBinding.root).create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dBinding.btnCancelHabit.setOnClickListener { dialog.dismiss() }
        dBinding.btnSaveHabit.setOnClickListener {
            val name = dBinding.etHabitName.text.toString().trim()
            if (name.isEmpty()) { dBinding.etHabitName.error = "Required"; return@setOnClickListener }
            vm.addHabit(Habit(
                name = name,
                nameTa = dBinding.etHabitNameTa.text.toString().trim(),
                icon = dBinding.etHabitIcon.text.toString().trim().ifEmpty { "⚡" },
                color = dBinding.etHabitColor.text.toString().trim().ifEmpty { "#C9A84C" }
            ))
            dialog.dismiss()
        }
        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
