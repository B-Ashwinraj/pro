package com.cageddragon.timeforge.ui.today

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.cageddragon.timeforge.R
import com.cageddragon.timeforge.data.Task
import com.cageddragon.timeforge.databinding.DialogAddTaskBinding
import com.cageddragon.timeforge.databinding.FragmentTodayBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TodayFragment : Fragment() {
    private var _binding: FragmentTodayBinding? = null
    private val binding get() = _binding!!
    private val vm: TodayViewModel by viewModels()
    private lateinit var adapter: TaskAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTodayBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = TaskAdapter(onToggle = { vm.toggleDone(it) }, onDelete = { vm.deleteTask(it) })
        binding.rvTasks.layoutManager = LinearLayoutManager(requireContext())
        binding.rvTasks.adapter = adapter

        val dateStr = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
        binding.tvDate.text = dateStr

        vm.tasks.observe(viewLifecycleOwner) { tasks ->
            adapter.submitList(tasks)
            val done = tasks.count { it.done }
            val total = tasks.size
            val pct = if (total > 0) done * 100 / total else 0
            binding.tvDoneCount.text = "$done/$total"
            binding.tvPct.text = "$pct%"
            binding.progressBar.progress = pct
            binding.tvProgressLabel.text = "$done/$total · $pct%"
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val overdue = tasks.count { !it.done && it.deadline.isNotEmpty() && it.deadline < today }
            binding.tvOverdueCount.text = overdue.toString()
            if (tasks.isEmpty()) {
                binding.rvTasks.visibility = View.GONE
                binding.tvEmpty.visibility = View.VISIBLE
            } else {
                binding.rvTasks.visibility = View.VISIBLE
                binding.tvEmpty.visibility = View.GONE
            }
        }
        binding.fabAddTask.setOnClickListener { showAddTaskDialog() }
    }

    private fun showAddTaskDialog(existing: Task? = null) {
        val dBinding = DialogAddTaskBinding.inflate(layoutInflater)
        val importanceOptions = arrayOf("Critical", "High", "Medium", "Low")
        val impAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, importanceOptions)
        impAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        dBinding.spImportance.adapter = impAdapter
        existing?.let {
            dBinding.etTaskName.setText(it.name)
            dBinding.etCategory.setText(it.category)
            dBinding.etStartTime.setText(it.startTime)
            dBinding.etDuration.setText(it.duration.toString())
            dBinding.etNotes.setText(it.notes)
            dBinding.spImportance.setSelection(importanceOptions.indexOfFirst { o -> o.lowercase() == it.importance }.takeIf { i -> i >= 0 } ?: 2)
        }
        val dialog = AlertDialog.Builder(requireContext()).setView(dBinding.root).create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dBinding.btnCancel.setOnClickListener { dialog.dismiss() }
        dBinding.btnSaveTask.setOnClickListener {
            val name = dBinding.etTaskName.text.toString().trim()
            if (name.isEmpty()) { dBinding.etTaskName.error = "Required"; return@setOnClickListener }
            val imp = importanceOptions[dBinding.spImportance.selectedItemPosition].lowercase()
            val task = Task(
                id = existing?.id ?: 0,
                name = name,
                importance = imp,
                startTime = dBinding.etStartTime.text.toString().trim(),
                duration = dBinding.etDuration.text.toString().toIntOrNull() ?: 30,
                category = dBinding.etCategory.text.toString().trim(),
                notes = dBinding.etNotes.text.toString().trim()
            )
            if (existing != null) vm.updateTask(task) else vm.addTask(task)
            dialog.dismiss()
        }
        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
