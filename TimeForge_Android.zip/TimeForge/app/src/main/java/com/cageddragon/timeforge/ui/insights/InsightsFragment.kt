package com.cageddragon.timeforge.ui.insights

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.cageddragon.timeforge.databinding.FragmentInsightsBinding

class InsightsFragment : Fragment() {
    private var _binding: FragmentInsightsBinding? = null
    private val binding get() = _binding!!
    private val vm: InsightsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInsightsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // Observe all data sources and recompute on any change
        vm.tasks.observe(viewLifecycleOwner) { tasks ->
            val goals = vm.goals.value ?: emptyList()
            val habits = vm.habits.value ?: emptyList()
            val sessions = vm.sessions.value ?: emptyList()
            vm.compute(tasks, goals, habits, sessions)
        }
        vm.goals.observe(viewLifecycleOwner) { goals ->
            val tasks = vm.tasks.value ?: emptyList()
            val habits = vm.habits.value ?: emptyList()
            val sessions = vm.sessions.value ?: emptyList()
            vm.compute(tasks, goals, habits, sessions)
        }
        vm.habits.observe(viewLifecycleOwner) { habits ->
            val tasks = vm.tasks.value ?: emptyList()
            val goals = vm.goals.value ?: emptyList()
            val sessions = vm.sessions.value ?: emptyList()
            vm.compute(tasks, goals, habits, sessions)
        }
        vm.sessions.observe(viewLifecycleOwner) { sessions ->
            val tasks = vm.tasks.value ?: emptyList()
            val goals = vm.goals.value ?: emptyList()
            val habits = vm.habits.value ?: emptyList()
            vm.compute(tasks, goals, habits, sessions)
        }

        vm.stats.observe(viewLifecycleOwner) { s ->
            binding.tvTasksDoneVal.text = "${s.tasksDoneToday}/${s.tasksToday}"
            binding.tvFocusMinsVal.text = "${s.focusMinutesToday} min"
            binding.tvFocusSessionsVal.text = "${s.focusSessionsToday} sessions"
            binding.tvTopStreakVal.text = "${s.topHabitStreak} days"
            binding.tvHabitsTodayVal.text = "${s.habitsCompletedToday}/${s.activeHabits}"
            binding.tvGoalsProgressVal.text = "${s.avgGoalProgress}%"
            binding.tvGoalsActiveVal.text = "${s.goalsInProgress} active"
            binding.tvGoalsDoneVal.text = "${s.goalsCompleted} achieved"
            binding.tvRecommendation.text = s.recommendation

            // Progress bar for task completion
            val pct = if (s.tasksToday > 0) s.tasksDoneToday * 100 / s.tasksToday else 0
            binding.progressTasks.progress = pct
            binding.progressGoals.progress = s.avgGoalProgress
            val habitPct = if (s.activeHabits > 0) s.habitsCompletedToday * 100 / s.activeHabits else 0
            binding.progressHabits.progress = habitPct
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
