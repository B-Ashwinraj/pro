package com.cageddragon.timeforge.ui.goals

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cageddragon.timeforge.R
import com.cageddragon.timeforge.data.Goal
import com.cageddragon.timeforge.databinding.ItemGoalBinding

class GoalAdapter(
    private val onNudge: (Goal, Int) -> Unit,
    private val onDelete: (Goal) -> Unit
) : ListAdapter<Goal, GoalAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemGoalBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemGoalBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val goal = getItem(position)
        val b = holder.binding
        val ctx = b.root.context
        b.tvGoalName.text = goal.name
        b.tvGoalDesc.text = goal.description
        b.tvHorizon.text = goal.horizon
        b.goalProgress.progress = goal.progress
        b.tvProgressPct.text = "${goal.progress}% complete"
        b.tvProgressLeft.text = if (goal.progress >= 100) "Achieved!" else "${100 - goal.progress}% to go"
        val impColor = when (goal.importance) {
            "critical" -> ContextCompat.getColor(ctx, R.color.crit)
            "high"     -> ContextCompat.getColor(ctx, R.color.high)
            "medium"   -> ContextCompat.getColor(ctx, R.color.med)
            else       -> ContextCompat.getColor(ctx, R.color.low)
        }
        b.impDot.setBackgroundColor(impColor)
        b.btnMinus10.setOnClickListener { onNudge(goal, -10) }
        b.btnMinus5.setOnClickListener { onNudge(goal, -5) }
        b.btnPlus5.setOnClickListener { onNudge(goal, 5) }
        b.btnPlus10.setOnClickListener { onNudge(goal, 10) }
        b.btnDeleteGoal.setOnClickListener { onDelete(goal) }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Goal>() {
            override fun areItemsTheSame(a: Goal, b: Goal) = a.id == b.id
            override fun areContentsTheSame(a: Goal, b: Goal) = a == b
        }
    }
}
