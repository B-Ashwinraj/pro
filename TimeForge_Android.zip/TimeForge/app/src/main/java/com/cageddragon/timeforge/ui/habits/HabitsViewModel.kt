package com.cageddragon.timeforge.ui.habits

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cageddragon.timeforge.data.Habit
import com.cageddragon.timeforge.data.Repository
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class HabitsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)
    val habits = repo.habits
    private val gson = Gson()

    fun addHabit(habit: Habit) = viewModelScope.launch { repo.insertHabit(habit) }
    fun deleteHabit(habit: Habit) = viewModelScope.launch { repo.deleteHabit(habit) }

    fun toggleToday(habit: Habit) {
        val today = todayKey()
        val log = parseLog(habit.logJson).toMutableMap()
        if (log.containsKey(today)) log.remove(today) else log[today] = true
        val newStreak = calcStreak(log)
        val newBest = maxOf(habit.best, newStreak)
        viewModelScope.launch {
            repo.updateHabit(habit.copy(logJson = gson.toJson(log), streak = newStreak, best = newBest))
        }
    }

    fun parseLog(json: String): Map<String, Boolean> {
        return try {
            val type = object : TypeToken<Map<String, Boolean>>() {}.type
            gson.fromJson(json, type) ?: emptyMap()
        } catch (e: Exception) { emptyMap() }
    }

    fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    fun last14Keys(): List<String> {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return (13 downTo 0).map { i ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -i)
            sdf.format(cal.time)
        }
    }

    private fun calcStreak(log: Map<String, Boolean>): Int {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        var streak = 0
        val cal = Calendar.getInstance()
        if (log[sdf.format(cal.time)] == true) streak++
        cal.add(Calendar.DAY_OF_YEAR, -1)
        while (true) {
            val k = sdf.format(cal.time)
            if (log[k] == true) { streak++; cal.add(Calendar.DAY_OF_YEAR, -1) } else break
        }
        return streak
    }
}
