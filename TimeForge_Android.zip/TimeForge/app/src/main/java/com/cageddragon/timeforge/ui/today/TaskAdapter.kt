package com.cageddragon.timeforge.ui.today

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cageddragon.timeforge.R
import com.cageddragon.timeforge.data.Task
import com.cageddragon.timeforge.databinding.ItemTaskBinding

class TaskAdapter(
    private val onToggle: (Task) -> Unit,
    private val onDelete: (Task) -> Unit
) : ListAdapter<Task, TaskAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemTaskBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val task = getItem(position)
        val b = holder.binding
        val ctx = b.root.context
        b.tvTaskName.text = task.name
        if (task.done) {
            b.tvTaskName.paintFlags = b.tvTaskName.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            b.tvTaskName.alpha = 0.5f
        } else {
            b.tvTaskName.paintFlags = b.tvTaskName.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            b.tvTaskName.alpha = 1f
        }
        val meta = buildString {
            if (task.startTime.isNotEmpty()) append(task.startTime)
            if (task.duration > 0) append(" · ${task.duration}min")
            if (task.category.isNotEmpty()) append(" · ${task.category}")
        }
        b.tvTaskMeta.text = meta
        val impColor = when (task.importance) {
            "critical" -> ContextCompat.getColor(ctx, R.color.crit)
            "high"     -> ContextCompat.getColor(ctx, R.color.high)
            "medium"   -> ContextCompat.getColor(ctx, R.color.med)
            else       -> ContextCompat.getColor(ctx, R.color.low)
        }
        b.impBar.setBackgroundColor(impColor)
        b.cbDone.setOnCheckedChangeListener(null)
        b.cbDone.isChecked = task.done
        b.cbDone.setOnCheckedChangeListener { _, _ -> onToggle(task) }
        b.btnDelete.setOnClickListener { onDelete(task) }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Task>() {
            override fun areItemsTheSame(a: Task, b: Task) = a.id == b.id
            override fun areContentsTheSame(a: Task, b: Task) = a == b
        }
    }
}
