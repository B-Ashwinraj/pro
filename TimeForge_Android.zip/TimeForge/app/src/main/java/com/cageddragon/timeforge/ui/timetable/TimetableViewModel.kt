package com.cageddragon.timeforge.ui.timetable
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cageddragon.timeforge.data.Repository
import com.cageddragon.timeforge.data.TimetableBlock
import kotlinx.coroutines.launch
class TimetableViewModel(app: Application) : AndroidViewModel(app) {
private val repo = Repository(app)
val blocks = repo.timetableBlocks
fun addBlock(block: TimetableBlock) = viewModelScope.launch { repo.insertBlock(block) }
fun deleteBlock(block: TimetableBlock) = viewModelScope.launch { repo.deleteBlock(block) }
}