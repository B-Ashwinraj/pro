package com.cageddragon.timeforge

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.cageddragon.timeforge.databinding.ActivityMainBinding
import com.cageddragon.timeforge.ui.today.TodayFragment
import com.cageddragon.timeforge.ui.timer.TimerFragment
import com.cageddragon.timeforge.ui.goals.GoalsFragment
import com.cageddragon.timeforge.ui.habits.HabitsFragment
import com.cageddragon.timeforge.ui.timetable.TimetableFragment
import com.cageddragon.timeforge.ui.review.ReviewFragment
import com.cageddragon.timeforge.ui.insights.InsightsFragment

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (savedInstanceState == null) {
            loadFragment(TodayFragment())
        }
        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_today     -> TodayFragment()
                R.id.nav_timer     -> TimerFragment()
                R.id.nav_goals     -> GoalsFragment()
                R.id.nav_habits    -> HabitsFragment()
                R.id.nav_timetable -> TimetableFragment()
                R.id.nav_review    -> ReviewFragment()
                R.id.nav_insights  -> InsightsFragment()
                else               -> TodayFragment()
            }
            loadFragment(fragment)
            true
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}
