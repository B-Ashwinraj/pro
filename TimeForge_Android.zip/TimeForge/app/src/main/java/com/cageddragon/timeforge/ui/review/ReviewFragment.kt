package com.cageddragon.timeforge.ui.review

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.cageddragon.timeforge.databinding.FragmentReviewBinding

class ReviewFragment : Fragment() {
    private var _binding: FragmentReviewBinding? = null
    private val binding get() = _binding!!
    private val vm: ReviewViewModel by viewModels()

    private val moods = listOf("🔥 Fired Up", "🎯 Focused", "😐 Okay", "😴 Tired", "😤 Frustrated", "😌 Calm")
    private var selectedMood = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setupMoodChips()

        vm.loadToday()
        vm.todayReview.observe(viewLifecycleOwner) { review ->
            review?.let {
                binding.etWins.setText(it.wins)
                binding.etLearnings.setText(it.learnings)
                binding.etTop3.setText(it.top3)
                binding.etImprove.setText(it.improve)
                selectedMood = it.mood
                updateMoodSelection()
                binding.tvSavedBadge.visibility = View.VISIBLE
            } ?: run {
                binding.tvSavedBadge.visibility = View.GONE
            }
        }

        binding.btnSaveReview.setOnClickListener {
            val mood = selectedMood
            val wins = binding.etWins.text.toString().trim()
            val learnings = binding.etLearnings.text.toString().trim()
            val top3 = binding.etTop3.text.toString().trim()
            val improve = binding.etImprove.text.toString().trim()

            if (wins.isEmpty() && learnings.isEmpty() && top3.isEmpty() && improve.isEmpty()) {
                Toast.makeText(requireContext(), "Add at least one reflection", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.saveReview(mood, wins, learnings, top3, improve)
            Toast.makeText(requireContext(), "Reflection saved ✓", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupMoodChips() {
        val chips = listOf(
            binding.chipMood0,
            binding.chipMood1,
            binding.chipMood2,
            binding.chipMood3,
            binding.chipMood4,
            binding.chipMood5
        )
        moods.forEachIndexed { i, mood ->
            chips[i].text = mood
            chips[i].setOnClickListener {
                selectedMood = mood
                updateMoodSelection()
            }
        }
    }

    private fun updateMoodSelection() {
        val chips = listOf(
            binding.chipMood0,
            binding.chipMood1,
            binding.chipMood2,
            binding.chipMood3,
            binding.chipMood4,
            binding.chipMood5
        )
        val gold = requireContext().getColor(com.cageddragon.timeforge.R.color.gold)
        val navy = requireContext().getColor(com.cageddragon.timeforge.R.color.navy)
        val surface = requireContext().getColor(com.cageddragon.timeforge.R.color.surface)
        val textMuted = requireContext().getColor(com.cageddragon.timeforge.R.color.text_muted)
        chips.forEachIndexed { i, chip ->
            if (moods[i] == selectedMood) {
                chip.backgroundTintList = android.content.res.ColorStateList.valueOf(gold)
                chip.setTextColor(navy)
            } else {
                chip.backgroundTintList = android.content.res.ColorStateList.valueOf(surface)
                chip.setTextColor(textMuted)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
