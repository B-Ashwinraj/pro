package com.cageddragon.timeforge.ui.review

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.cageddragon.timeforge.data.Repository
import com.cageddragon.timeforge.data.Review
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReviewViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)
    val reviews = repo.reviews

    val todayReview = MutableLiveData<Review?>()

    fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    fun loadToday() {
        viewModelScope.launch {
            todayReview.postValue(repo.getReviewByDate(todayKey()))
        }
    }

    fun saveReview(mood: String, wins: String, learnings: String, top3: String, improve: String) {
        val review = Review(
            dateKey = todayKey(),
            mood = mood,
            wins = wins,
            learnings = learnings,
            top3 = top3,
            improve = improve
        )
        viewModelScope.launch {
            repo.insertReview(review)
            todayReview.postValue(review)
        }
    }
}
